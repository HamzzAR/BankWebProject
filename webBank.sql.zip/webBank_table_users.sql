
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `acno` char(5) NOT NULL,
  `password` char(20) NOT NULL,
  `role` int(1) NOT NULL,
  `active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`acno`, `password`, `role`, `active`) VALUES
('CM001', '1', 1, 1),
('CM000', 'root', 0, 1);
