
-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `acno` char(5) NOT NULL,
  `name` char(16) NOT NULL,
  `address` char(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`acno`, `name`, `address`) VALUES
('CM001', 'Hamza Ar', '2 the road');
