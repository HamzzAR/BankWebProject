
-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `acno` char(5) NOT NULL,
  `amount` int(6) NOT NULL,
  `type` char(1) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`acno`, `amount`, `type`, `date`) VALUES
('CM001', 100, 'd', '2019-05-20'),
('CM001', 1000, 'd', '2019-05-20');
